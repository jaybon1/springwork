package com.cos.jwtex01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jwtex01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
