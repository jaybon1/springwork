package com.cos.jwtex01.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @Column(unique = true)
    private String username;
    private String password;
    private String email;
    private String roles;
    private String providerId;
    private String provider;

    // ENUM으로 안하고 ,로 해서 구분해서 ROLE을 입력 -> 그걸 파싱!!
    public List<String> getRoleList(){
    	System.out.println("model.User의 getRoleList()에 왔습니다");
        if(this.roles.length() > 0){
        	System.out.println("model.User의 getRoleList()의 if문에 왔습니다");
            return Arrays.asList(this.roles.split(","));
        }

        return new ArrayList<>();
    }
}
